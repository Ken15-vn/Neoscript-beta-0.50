import time
import os
import sys

# Kho lưu trữ biến số
variables = {}

def run_neo_script(file_path):
    # Hệ màu NeoScript
    colors = {
        "green": "\033[92m",
        "red": "\033[91m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "cyan": "\033[96m",
        "white": "\033[0m"
    }

    print(f"{colors['cyan']}--- Welcome to NeoScript Beta 0.50 ---{colors['white']}")

    # Kiểm tra đuôi file .ns và sự tồn tại của file
    if not file_path.endswith('.ns'):
        print(f"{colors['red']}Error: NeoScript 0.50 chi ho tro dinh dang .ns!{colors['white']}")
        return
    if not os.path.exists(file_path):
        print(f"{colors['red']}Error: Khong tim thay file '{file_path}'!{colors['white']}")
        return

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"): 
                continue

            # --- CÁC TÍNH NĂNG KẾ THỪA ---
            if line.startswith("wait "):
                time.sleep(float(line[5:]))
            elif line == "clear":
                os.system('cls' if os.name == 'nt' else 'clear')
            elif line.startswith("color "):
                c = line[6:].strip().strip('"').lower()
                if c in colors: sys.stdout.write(colors[c])
            elif line.startswith("set "):
                parts = line.split()
                if len(parts) >= 3:
                    variables[parts[1].strip('"')] = float(parts[2])
            elif line.startswith("add "):
                parts = line.split()
                if len(parts) >= 3:
                    var_name = parts[1].strip('"')
                    if var_name in variables: variables[var_name] += float(parts[2])

            # --- 2 TÍNH NĂNG MỚI (Beta 0.50) ---
            # 1. sub: Trừ giá trị biến
            elif line.startswith("sub "):
                parts = line.split()
                if len(parts) >= 3:
                    var_name = parts[1].strip('"')
                    if var_name in variables: variables[var_name] -= float(parts[2])

            # 2. input: Nhập số từ bàn phím
            elif line.startswith("input "):
                var_name = line[6:].strip().strip('"')
                try:
                    user_val = input(f"Enter numeric value for {var_name}: ")
                    variables[var_name] = float(user_val)
                except ValueError:
                    print(f"{colors['red']}Error: Nhap sai kieu du lieu!{colors['white']}")

            # Lệnh write (Cải tiến)
            elif line.startswith("write "):
                content = line[6:].strip().strip('"')
                if content in variables:
                    print(variables[content])
                else:
                    print(content)
                sys.stdout.flush()

        print(f"{colors['green']}Process finished successfully!{colors['white']}")

    except Exception as e:
        print(f"{colors['red']}NeoScript System Error: {e}{colors['white']}")

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "ide.ns"
    run_neo_script(target)