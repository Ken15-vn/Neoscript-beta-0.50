@echo off
cd /d "%~dp0"
python Neoscript_beta_0.50.py ide.ns
pause